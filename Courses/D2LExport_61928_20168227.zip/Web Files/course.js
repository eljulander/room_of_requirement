/********************************************************
    The purpose of course.js is to house only the JavaScript
    specific to an individual course. The online.js
    houses all the default JavaScript.
********************************************************/
/* DO NOT DELETE OR MODIFY THIS SECTION */
/* Append Script Tag for Online.js to the Body Tag */
var onlineJs = document.createElement("script");
onlineJs.src = 'https://content.byui.edu/integ/gen/00134d04-34d1-47b8-9242-c29059c522ee/0/online.js';
document.body.appendChild(onlineJs);

/* Add Course Specific JavaScript Below */
